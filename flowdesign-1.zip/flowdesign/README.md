# flowdesign

Two collaborative **planning** skills for Claude Code, extracted from
[flowcode](https://github.com/ekain-fr/splitio/tree/main/packages/flowcode):

- **`/flowdesign:discover`** — turn a product idea into a **PRD** (Product Requirements
  Document) with user personas, user stories, and MoSCoW prioritization.
- **`/flowdesign:study`** — turn an idea or a single story into a fully-formed
  **design document** through collaborative dialogue.

This is a **pure-markdown plugin** — no Python, no build CLI, no external tooling. The
skills drive a structured conversation, run three requirements-review agents
(contrarian / first-principles / expansionist), and write their output under
`output/<date>-<slug>/` as plain files — no git is required or performed. After `study`
produces the design doc, you implement directly — there is no orchestrator/build step.

## Install

```bash
# 1. Register the marketplace (use the local path, or a git URL once pushed)
/plugin marketplace add /path/to/flowdesign

# 2. Install the plugin
/plugin install flowdesign@flowdesign-dev
```

Then enable it in `~/.claude/settings.json`:

```json
{
  "enabledPlugins": {
    "flowdesign@flowdesign-dev": true
  }
}
```

## Usage

```text
/flowdesign:discover     →  PRD with prioritized user stories
        │
        ▼
/flowdesign:study <story>  →  design document
        │
        ▼
   implement directly
```

`discover` is optional — for a single feature you can start straight at
`/flowdesign:study`. For a new product, run `discover` first to break it into stories,
then `study` each story.

### Output

Both skills write plain files to `output/<YYYY-MM-DD>-<feature-slug>/` in your project
(no git operations are performed):

- `discover` → `<feature>-prd.md` plus `<feature>-prd.html` (a self-contained, single-page
  HTML version with a sidebar table of contents)
- `study` → `<feature>-design.md`

## What's inside

```
flowdesign/
├── .claude-plugin/         plugin.json + marketplace.json
├── skills/
│   ├── discover/SKILL.md   + reference/ example PRDs (en/fr)
│   └── study/SKILL.md
├── agents/                 req-review-{contrarian,first-principles,expansionist}
└── docs/                   flowzy-quick-reference.md + flowzy-spec.md (the DSL the skills are written in)
```

The skills are authored in **Flowzy**, a small DSL for procedural workflows; the full
spec and a quick reference live in `docs/` and are read by the skills at runtime.
