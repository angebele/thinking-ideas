# Flowzy Quick Reference

<flowzy-quick-reference>

Interpret the following Flowzy process (identified as `flowzy` language) LITERALLY:

- Structured keywords define control flow
- '-' is an atomic action (duplicates allowed)
- Conditions are opaque labels in { }
- Indentation defines scope
- '#' denotes comments
- Execute the process LITERALLY as described: DO NOT infer unstated behavior or add implicit error handling.

## Flowzy DSL Constructs

| Construct | Syntax | Behavior |
| ----------- | -------- | ---------- |
| Process | `process Name:` | Root container (exactly one per file) |
| Step | `- action` | Atomic action (duplicates allowed) |
| Result | `result:` + comma-separated identifiers | Named step output; reference later as `<name>` |
| Run | `run: \|` + indented content | Tool/command invocation (follow strictly, substitute values) |
| Rules | `rules:` + indented `-` items | Constraints/instructions for executing the parent step |
| Format | `format: \|` + indented content | Required output structure (follow strictly, substitute values) |
| Example | `example: \|` + indented content | Illustrative output (match spirit, adapt freely) |
| Condition | `{text}` | Opaque label—never parsed or evaluated |
| Branching | `if/elsif/else/end-if` | First matching branch executes; at most one |
| Pre-check loop | `while {cond}/end-while` | Loop WHILE condition is true; may run 0 times |
| Post-check loop | `repeat/until {cond}` | Loop UNTIL condition becomes true; runs ≥1 time |
| Collection loop | `for-each {x in y}/end-for` | Iterate over collection; runs once per item |
| Grouping | `group Name/end-group` | Logical scope only—no control flow effect |
| Parallelism | `parallel/branch/end-parallel` | Fork-join model: all branches complete before continuing |
| Comment | `# text` | For documentation only; ignored by execution |

## Flowzy Idiomatic Step Verbs

Use domain verbs in step descriptions — tool names belong in `run:` blocks.

| Verb | Purpose | Implied Tool | Example |
| -------- | ---------------------------------------- | -------------------- | ------------------------------------------------- |
| `Output` | Display a message to the user | Direct text output | `- Output process status` + `format:` block |
| `Ask` | Ask the user a question and wait | `AskUserQuestion` | `- Ask if the user approves the plan` |
| `Invoke` | Run another skill in current context | `Skill` tool | `- Invoke skill 'flowcode:writing-plans'` |
| `Launch` | Start a subagent and wait for result | `Task` tool | `- Launch 'diagram-verifier' to verify output` |

## Full Flowzy Specification **(read only if necessary)**

The full Flowzy specification is available here: [full Flowzy spec](./flowzy-spec.md)

---
</flowzy-quick-reference>
