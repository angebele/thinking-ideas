# Flowzy — Full Specification

## 1. Purpose

A minimal, structured DSL for describing **procedural workflows/processes** with:

- ordered atomic actions  
- explicit decision points  
- bounded and unbounded loops  
- logical grouping  
- structured parallel execution  

The DSL is optimized for:

- deterministic AI parsing and reasoning (Claude Code–style agents)
- lossless transformation (→ Mermaid, code, tests)
- human readability with low cognitive load

Treat this DSL as **authoritative code**, not documentation.

**Code fence:** Use ` ```flowzy ` for all Flowzy blocks in markdown documents.

---

## 2. Core Design Principles

1. Structured control flow only  
2. Indentation defines scope  
3. Explicit over implicit  
4. Duplicate actions are allowed and intentional  
5. Conditions are opaque and never interpreted  
6. No hidden or inferred behavior  
7. Parallelism is explicit and structured (fork–join only)

---

## 3. Lexical Rules

### Indentation

- Indentation is **semantic**
- Spaces only (recommended: 2)
- Tabs forbidden
- All sibling blocks must align

### Lines

- One construct per line
- Empty lines allowed
- Comments allowed

---

## 4. Comments

Comments start with `#`.

```text
# Full-line comment
- Do something  # Inline comment
```

- Comments have no semantic meaning
- Ignored by execution, analysis, and transformation

---

## 5. Reserved Keywords

```text
process
group
if
elsif
else
while
repeat
until
for-each
parallel
branch
end-group
end-if
end-while
end-for
end-parallel
result
run
rules
format
example
-
```

---

## 6. Identifiers and Literals

### Step IDs (Optional)

```text
- [step_id] Step description
```

Rules:

- Optional
- Unique within a process
- Metadata only (no control-flow semantics)

### Conditions

```text
{condition text}
```

Rules:

- Opaque strings
- Not parsed or interpreted by the DSL

---

## 7. Core Constructs

### Process (Root)

```text
process <process_name>:
  <block>+
```

- Exactly one `process`
- Must be the root construct

---

### Atomic Step

```text
- [<step_id>] <description>
```

- Exactly one atomic action
- No nested blocks
- Action duplication is allowed

---

### Result (Named Step Output)

```text
- <step description>
  result: <identifier>
```

Or with multiple outputs:

```text
- <step description>
  result: <identifier>, <identifier>
```

- Must follow an atomic step (before `run:`, `rules:`, `format:`, `example:`)
- Declares the named output(s) of a step
- Later steps reference the value using `<identifier>` (angle brackets)
- Identifiers must be lowercase with hyphens: `[a-z][a-z0-9-]*`
- Identifiers must be unique within a process, except that mutually exclusive branches of the same `if/elsif/else` may each declare the same identifier
- Does not affect control flow

---

### Run (Tool/Command Invocation)

```text
- <step description>
  run: |
    <invocation template>
    <with preserved newlines>
```

- Must follow an atomic step (after `result:` if present, before `rules:`)
- Defines the tool or command to invoke for this step
- AI must follow this invocation structure strictly, only substituting values
- Uses concrete placeholder values that AI replaces with actual data
- Does not affect control flow

---

### Rules (Step Elaboration)

```text
- <step description>
  rules:
    - <instruction>
    - <instruction>
```

- Must follow an atomic step (after `result:` and `run:` if present)
- Contains constraints/instructions for executing the step
- Does not affect control flow
- Items are rules to follow, not sub-steps

---

### Format (Required Output Structure)

```text
- <step description>
  format: |
    <required structure>
    <with preserved newlines>
```

- Must follow an atomic step (after `result:`, `run:`, and `rules:` if present, before `example:`)
- Defines the required output structure
- AI must follow this structure strictly, only substituting values
- Uses concrete placeholder values that AI replaces with actual data
- Does not affect control flow

---

### Example (Illustrative Output)

```text
- <step description>
  example: |
    <illustrative output>
    <with preserved newlines>
```

- Must follow an atomic step (after `result:`, `run:`, `rules:`, and `format:` if present)
- Shows what good output looks like
- AI should match the spirit and structure, adapting freely as appropriate
- Uses concrete values for illustration
- Does not affect control flow

---

### Step Elaboration Keywords — When to Use Which

A step describes *what* to do. The five elaboration keywords describe *how*, each with a distinct role:

| Keyword | Purpose | Strictness | Content |
| --------- | --------- | ------------ | --------- |
| `result:` | What the step produces | Exact identifier | Named output(s) referenced later as `<name>` |
| `run:` | How to execute (tool/command) | Strict — substitute values only | Structured invocation template |
| `rules:` | Constraints on execution | Flexible — follow the intent | Behavioral instructions and guardrails |
| `format:` | Required text/output structure | Strict — substitute values only | Text template for user-facing output |
| `example:` | What good output looks like | Loose — match spirit, adapt freely | Illustrative sample output |

**Key distinctions:**

- **`run:` vs `format:`** — Both use strict substitution templates, but `run:` describes a tool or command invocation (e.g., `Bash`, `Skill`), while `format:` describes user-facing text output (e.g., a summary, a message). If the step calls a tool, use `run:`. If it produces text for the user, use `format:`.

- **`run:` vs `rules:`** — `run:` is the invocation template (the *what to call*), `rules:` is behavioral constraints (the *how to behave*). They complement each other: `run:` says "call `Bash: mkdir -p ./output`", `rules:` says "Don't fail if the directory already exists."

- **`format:` vs `example:`** — `format:` is a strict template (AI substitutes values but preserves structure exactly). `example:` is illustrative (AI matches the spirit but adapts freely). Use `format:` when the output structure is required, `example:` when it's guidance.

- **Status/progress messages** — When a step needs to output a status message, announcement, or progress update to the user, use `Output` as the step verb with a `format:` block. This is the recommended pattern for all user-facing messages that don't involve tool invocations:

  ```text
  - Output process status
    format: |
      **Starting deployment process**
  ```

  Avoid embedding the message text directly in the step description (e.g., ~~`- Announce "Starting deployment"`~~). Separating the action (`Output`) from the content (`format:`) keeps the DSL explicit and consistent.

### Idiomatic Step Verbs

Four step verbs have idiomatic meaning in Flowzy. Using them consistently improves readability and enables lint enforcement.

| Verb | Purpose | Implied Tool | Example |
| ------ | --------- | ------------- | --------- |
| `Output` | Display a message to the user | Direct text output | `- Output process status` |
| `Ask` | Ask the user a question and wait for a response | `AskUserQuestion` | `- Ask if the user approves the plan` |
| `Invoke` | Run another skill and wait for it to complete | `Skill` tool | `- Invoke skill 'flowcode:writing-plans'` |
| `Launch` | Launch a subagent and wait for its result | `Task` tool | `- Launch 'flowzy-diagram-verifier' to verify diagram` |

**`Output`** is documented above (Status/progress messages).

**`Ask`** — Use when the process needs user input before continuing. Three forms:

  ```text
  - Ask one question to refine the idea
    rules:
      - Prefer multiple choice questions when possible
  ```

  ```text
  - Ask: "Ready to start execution now?"
  ```

  ```text
  - Ask for preview preferences
    run: |
      AskUserQuestion (single call, two questions):
        Q1: "Which method?"
          - Option A (Recommended): Description
          - Option B: Description
        Q2: "Which version?"
          - Option X (Recommended): Description
          - Option Y: Description
    rules:
      - Only show Q2 if condition is met
  ```

  The first form (descriptive) suits open-ended questions with behavioral constraints via `rules:`. The second form (quoted) suits yes/no gates or confirmations where the exact wording matters. The third form (structured) suits multi-question or multi-choice interactions where the exact questions and options must be specified — use a `run:` block with the full AskUserQuestion invocation structure. Do not reference tool names in Ask steps — write `- Ask for the file path`, not ~~`- Use AskUserQuestion to ask for the file path`~~.

**`Invoke`** — Use when the process delegates work to another skill. The skill name uses the `plugin:skill-name` format:

  ```text
  - Invoke skill 'flowcode:writing-plans' to create plan
  ```

  Optionally add a `run:` block when the invocation needs arguments:

  ```text
  - Invoke skill 'flowcode:writing-plans' to create plan
    run: |
      Skill: flowcode:writing-plans
        - topic: <design-topic>
        - output: <plan-file-path>
  ```

  Do not describe the tool mechanism in the step text — write `- Invoke skill 'flowcode:writing-plans'`, not ~~`- Use the Skill tool to invoke 'flowcode:writing-plans'`~~.

**`Launch`** — Use when the process launches a subagent (a separate agent context via the `Task` tool). Unlike `Invoke`, which loads a skill into the current context, `Launch` starts a fresh agent that runs independently and returns a result. Always include a `run:` block specifying the `Task` invocation. Three forms:

  **Named agent** — for plugin-defined agents (`agents/*.md`). Use the agent's name as declared in its frontmatter:

  ```text
  - Launch 'flowzy-diagram-verifier' to verify diagram
    run: |
      Task: subagent_type=flowzy-diagram-verifier
        - source file: <source-file>
        - diagram path: <diagram-path>
  ```

  **Built-in agent** — for built-in agent types (`Explore`, `general-purpose`, `Plan`):

  ```text
  - Launch Explore agent to find configuration files
    run: |
      Task: subagent_type=Explore
        "Find all configuration files and entry points"
  ```

  **Process executor** — for launching a flowzy sub-process via `flowzy-process-executor`. The sub-process lives as a plain markdown file with a `flowzy` code block:

  ```text
  - Launch flowzy-process-executor to run migration
    run: |
      Task: subagent_type=flowzy-process-executor
        "Execute docs/sub-processes/db-migration.md"
  ```

  Do not reference tool names or use informal dispatch verbs in the step text — write `- Launch 'flowzy-diagram-verifier' to verify diagram`, not ~~`- Delegate verification to 'flowzy-diagram-verifier'`~~, ~~`- Dispatch flowzy-diagram-verifier subagent`~~, or ~~`- Task: subagent_type=flowzy-diagram-verifier`~~.

**General principle:** Step descriptions use domain verbs (`Ask`, `Output`, `Invoke`, `Launch`) rather than tool names (`AskUserQuestion`, `Skill`, `Task`, `Bash`). Tool names belong in `run:` blocks. When a step invokes a tool that has no idiomatic verb, describe the action in domain terms and use `run:` for the tool call:

  ```text
  - Create output directory
    run: |
      Bash: mkdir -p ./output/reports
  ```

  Not: ~~`- Bash: mkdir -p ./output/reports`~~

**Ordering** — When multiple keywords appear on a step, they must follow this order:

```text
result: → run: → rules: → format: → example:
```

All are optional. Only include what the step needs.

---

### Group (Logical Scope)

```text
group <group_name>:
  <block>+
end-group
```

- Semantic grouping only
- Does not alter control flow

---

### Conditional

```text
if {condition}:
  <block>+
elsif {condition}:
  <block>+
else:
  <block>+
end-if
```

Rules:

- `if` required
- `elsif` optional (0+)
- `else` optional
- Conditions evaluated top-down
- First matching branch executes
- If none match and no `else`, the conditional is skipped
- At most one branch executes

---

### While Loop (Pre-condition)

```text
while {condition}, max-iterations=<number>:
  <block>+
end-while
```

Rules:

- `max-iterations` optional
- Condition evaluated before each iteration
- Loop exits when:
  - condition becomes false, or
  - max-iterations is reached

---

### Repeat / Until Loop (Post-condition)

```text
repeat:
  <block>+
until {condition}, max-iterations=<number>
```

Rules:

- Executes at least once
- `max-iterations` optional
- Condition evaluated after each iteration
- Loop exits when:
  - condition becomes true, or
  - max-iterations is reached

---

### For-Each Loop (Collection Iteration)

```text
for-each {item in collection}:
  <block>+
end-for
```

Rules:

- Iterates over each item in a conceptual collection
- The condition `{item in collection}` is an opaque label (not parsed)
- Loop body executes once per item
- Terminates when all items are processed
- Semantically distinct from `while` (bounded vs. potentially unbounded)

---

### Parallel Block (conceptually similar to Fork–Join)

```text
parallel:
  branch <branch_name>:
    <block>+
  branch <branch_name>:
    <block>+
end-parallel
```

Rules:

- One or more `branch` blocks required
- All branches start conceptually at the same time
- No defined execution order between branches
- Execution continues only after all branches complete
- Branch names are required and opaque
- No shared state is assumed

---

## 8. Explicit Non-Features

The DSL deliberately does **not** support:

- `goto` or jumps
- implicit guards
- boolean expressions
- parallel joins with conditions
- exceptions or error handling
- shared mutable state
- expressions or operators

---

## 9. Canonical Example

```flowzy
process CIWorkflow:

  parallel:
    branch build:
      - Compile code
      - Build artifacts

    branch test:
      - Run unit tests
      - Run integration tests

    branch lint:
      - Run linter
  end-parallel

  - Publish results
```

### Example with Rules

```flowzy
process Brainstorming:

  repeat:
    - Ask one question to refine the idea
      rules:
        - Prefer multiple choice questions when possible
        - Only one question per message
        - Focus on understanding: purpose, constraints, success criteria
  until {idea is sufficiently understood}

  - Propose solution
```

### Example with Format and Example

```flowzy
process PlanReview:

  - Output the plan summary to user
    rules:
      - Complexity thresholds: low (<5 tasks), medium (5-10), high (>10)
    format: |
      Plan created: <plan-file-path>

      Tasks: <task-count>
      Complexity: <low|medium|high>

      Confirm:
      - Are the tasks correctly scoped?
      - Any missing steps?

  repeat:
    - Ask if user approves or requests changes
    if {user requests changes}:
      - Update plan based on feedback
      - Output updated plan
        example: |
          Updated plan with your feedback:
          - Added database migration step
          - Split auth into two phases

          Tasks: 7
          Complexity: medium
    end-if
  until {user approves final plan}
```

### Example with Result

```flowzy
process APIScaffolding:

  - Create module directory for new API
    result: module-path
    format: |
      src/api/<module-name>/

  for-each {endpoint in API spec}:
    - Generate endpoint handler file
      format: |
        <module-path>/<endpoint-name>.ts
  end-for

  - Output module path for reference
```

### Example with Run

```flowzy
process SetupTracking:

  - Create tracking task
    result: task-id
    run: |
      Bash: fbt add task --title "Set up CI pipeline" --status todo -o json | jq -r '.data.id'

  - Create output directory
    run: |
      Bash: mkdir -p ./output/reports
    rules:
      - Don't fail if the directory already exists

  - Output summary to user
    format: |
      Setup complete.
      Tracking task: <task-id>
      Output directory: ./output/reports
```

---

## 10. Formal Grammar (EBNF)

```text
Process        ::= "process" WS Name ":" NL
                   Block+

Block          ::= Step
                 | Group
                 | If
                 | While
                 | RepeatUntil
                 | ForEach
                 | Parallel

Step           ::= INDENT "-" WS StepID? WS Text Comment? NL
                   Result?
                   Run?
                   Rules?
                   Format?
                   Example?

StepID         ::= "[" Text "]"

Result         ::= INDENT INDENT "result:" WS IdentList NL

IdentList      ::= Ident ("," WS Ident)*

Ident          ::= [a-z][a-z0-9-]*

Run            ::= INDENT INDENT "run:" WS "|" NL
                   RunContent

RunContent     ::= (INDENT INDENT INDENT AnyText NL)+

Rules          ::= INDENT INDENT "rules:" NL
                   RulesItem+

RulesItem      ::= INDENT INDENT INDENT "-" WS Text NL

Format         ::= INDENT INDENT "format:" WS "|" NL
                   FormatContent

FormatContent  ::= (INDENT INDENT INDENT AnyText NL)+

Example        ::= INDENT INDENT "example:" WS "|" NL
                   ExampleContent

ExampleContent ::= (INDENT INDENT INDENT AnyText NL)+

Group          ::= INDENT "group" WS Name ":" NL
                   Block+
                   INDENT "end-group" NL

If             ::= INDENT "if" WS Condition ":" NL
                   Block+
                   Elsif*
                   Else?
                   INDENT "end-if" NL

Elsif          ::= INDENT "elsif" WS Condition ":" NL
                   Block+

Else           ::= INDENT "else:" NL
                   Block+

While          ::= INDENT "while" WS Condition
                   ("," WS LoopOption)?
                   ":" NL
                   Block+
                   INDENT "end-while" NL

RepeatUntil    ::= INDENT "repeat:" NL
                   Block+
                   INDENT "until" WS Condition
                   ("," WS LoopOption)? NL

ForEach        ::= INDENT "for-each" WS Condition ":" NL
                   Block+
                   INDENT "end-for" NL

Parallel       ::= INDENT "parallel:" NL
                   Branch+
                   INDENT "end-parallel" NL

Branch         ::= INDENT "branch" WS Name ":" NL
                   Block+

LoopOption     ::= "max-iterations" "=" Number
```

---

## 11. Linting Rules

Rules for validating Flowzy processes. Severity levels:

- **error** — structurally invalid; must be fixed
- **warning** — likely unintentional; should be reviewed

**IMPORTANT:** Any changes to this section MUST also be reflected in `skills/flowzy/SKILL.md`, which implements these rules in its `LintFlowcodeDSL` process.

### Structure

| ID | Severity | Rule | Spec |
| ---- | -------- | ---- | ---- |
| S1 | error | Every block construct (`group`, `if`, `elsif`, `else`, `while`, `repeat`, `for-each`, `parallel`, `branch`) must contain at least one child block | §10: `Block+` |
| S2 | error | Every `group`/`if`/`while`/`for-each`/`parallel` must have its matching `end-*` terminator | §7 |
| S3 | error | An `end-*` keyword must match its opening keyword (e.g., `if` cannot be closed by `end-while`) | §7 |
| S4 | warning | A `parallel:` block should contain at least two `branch` blocks (single-branch is sequential) | §7 Parallel |
| S5 | error | Exactly one `process` declaration required; must be the root construct | §7 Process |
| S6 | error | A `process` must contain at least one block | §10: `Block+` |

### Elaboration

| ID | Severity | Rule | Spec |
| ---- | -------- | ---- | ---- |
| E1 | error | Elaboration keywords must not be empty: `rules:` needs ≥1 item, `run:`/`format:`/`example:` need ≥1 content line, `result:` needs ≥1 identifier | §10 EBNF |
| E2 | error | Elaboration keywords must appear in order: `result:` → `run:` → `rules:` → `format:` → `example:` | §7 Ordering |
| E3 | error | Elaboration keywords (`result:`, `run:`, `rules:`, `format:`, `example:`) must be preceded by an atomic step | §7 |
| E4 | error | A step must not have duplicate elaboration keywords (e.g., two `rules:` blocks) | §10 EBNF |

### Result / Reference

| ID | Severity | Rule | Spec |
| ---- | -------- | ---- | ---- |
| R1 | error | Result identifiers must match `[a-z][a-z0-9-]*` | §7 Result |
| R2 | warning | Every `result:` identifier should be referenced at least once later via `<identifier>` | Principle 3 |
| R3 | warning | Every `<identifier>` reference should trace back to a `result:` declaration or `for-each` iteration variable | Principle 3 |
| R4 | error | Each `result:` identifier must be unique across the entire process, except that mutually exclusive branches (`if`/`elsif`/`else`) of the same conditional may each declare the same identifier | §7 Result |
| R5 | error | If any branch of an `if/elsif/else` declares a `result:` identifier, then every branch (including `else`) must declare the same set of `result:` identifiers. **Exception:** a branch may declare a `result:` that is only referenced within that same branch — such branch-scoped results do not trigger the all-branches requirement | §7 Result |

### Naming

| ID | Severity | Rule | Spec |
| ---- | -------- | ---- | ---- |
| N1 | error | `group` must have a name: `group <name>:` | §10 EBNF |
| N2 | error | `branch` must have a name: `branch <name>:` | §7 Parallel |
| N3 | error | `process` must have a name: `process <name>:` | §10 EBNF |
| N4 | warning | Group names should be unique within a process | — |
| N5 | warning | Branch names should be unique within the same `parallel:` block | — |

### Indentation Rules

| ID | Severity | Rule | Spec |
| ---- | -------- | ---- | ---- |
| I1 | error | Tabs are forbidden; use spaces only | §3 |
| I2 | error | All sibling constructs within the same block must use identical indentation depth | §3 |
| I3 | error | Each construct must occupy exactly one line (excluding multi-line elaboration content) | §3 |

### Control Flow

| ID | Severity | Rule | Spec |
| ---- | -------- | ---- | ---- |
| C1 | error | `elsif` and `else` can only appear inside an `if`…`end-if` block | §7 Conditional |
| C2 | error | `until` can only appear as the terminator of a `repeat:` block | §7 Repeat/Until |
| C3 | error | `branch` can only appear as a direct child of a `parallel:` block | §7 Parallel |
| C4 | error | A `parallel:` block can only contain `branch` blocks (and comments) | §10: `Branch+` |

### Complexity

| ID | Severity | Rule | Spec |
| ---- | -------- | ---- | ---- |
| X1 | warning | Process exceeds 30 atomic steps — consider decomposing via delegation to sub-skills or subagents | §12 |
| X2 | warning | Control-flow nesting depth exceeds 3 levels (e.g., for-each > repeat > if > while) — state-tracking drift likely. Only count `if`, `while`, `repeat`, `for-each`, `parallel`; `group` does not count | §12 |
| X3 | warning | Process has more than 8 `group` blocks — consider splitting into multiple processes | §12 |
| X4 | warning | Process has more than 5 loop constructs (`while`, `repeat`, `for-each`) — consider simplifying | §12 |
| X5 | warning | Process has more than 5 `if` blocks — consider simplifying decision logic | §12 |
| X6 | warning | Process has more than 6 total `branch` blocks — consider sequencing low-priority branches | §12 |
| X7 | warning | Process Complexity Score (PCS) exceeds 0.70 — process is complex; consider decomposition | §12 |
| X8 | warning | PCS exceeds 1.00 — process is critically complex; must decompose | §12 |

### Diction

| ID | Severity | Rule | Spec |
| ---- | -------- | ---- | ---- |
| D1 | warning | Step descriptions should not begin with a tool name (`AskUserQuestion`, `Bash`, `Glob`, `Grep`, `Read`, `Write`, `Edit`, `Skill`, `Task`) — use domain verbs and move tool references to `run:` blocks | §7 Idiomatic Step Verbs |
| D2 | warning | Steps that ask the user a question should use `Ask` as the step verb — not `Use AskUserQuestion` or similar tool-referencing phrasing | §7 Idiomatic Step Verbs |
| D3 | warning | Steps that invoke another skill should use `Invoke skill '<name>'` — not `Use the Skill tool to invoke '<name>'` or similar | §7 Idiomatic Step Verbs |
| D4 | warning | Steps that output a message to the user with a `format:` block should use `Output` as the step verb | §7 Idiomatic Step Verbs |
| D5 | warning | Steps that launch a subagent should use `Launch` as the step verb — not `Delegate`, `Dispatch subagent`, `Run subagent`, or `Task:` | §7 Idiomatic Step Verbs |

---

## 12. Process Complexity Guidelines

Guidance for authoring processes that AI agents (Claude Code) will follow precisely.

### Recommended Limits

| Dimension | Sweet Spot | Upper Bound | Notes |
| ----------- | ----------- | ------------- | ------- |
| Atomic steps | 15–25 | ~30 | Beyond 30, agents skip or compress mid-process steps |
| Nesting depth | 2 | 3 | Control-flow constructs only (`if`, `while`, `repeat`, `for-each`, `parallel`); `group` does not count. Depth 4+ causes state-tracking drift |
| Groups | 4–6 | 8 | Each group should represent a coherent phase |
| Loop constructs | 2–3 | 5 | Prefer bounded loops (`max-iterations`, `for-each`) over open `while` |
| Conditionals | 2–3 | ~5 | Count each `if` keyword; nested `if` blocks count separately |
| Parallel branches | 3–4 | ~6 | Total `branch` blocks across all `parallel:` blocks |

> **Run density (R):** Recommended minimum 0.30. Defined as `steps_with_run / S`, where `steps_with_run` is the count of atomic steps that have a `run:` elaboration keyword, and `S` is the total atomic step count. Higher run density improves agent fidelity (see Elaboration Keyword Fidelity above).

### Elaboration Keyword Fidelity

Agents follow elaboration keywords with varying precision. Ranked from highest to lowest fidelity:

| Keyword | Fidelity | Why |
| --------- | ---------- | ----- |
| `run:` | Highest | Strict template — agent substitutes values only |
| `format:` | High | Strict structure — agent preserves layout |
| `rules:` | Medium | Directional — agent follows intent but may paraphrase or skip items |
| `example:` | Low | Illustrative — agent matches spirit, adapts freely |

**Implication:** Processes requiring precise execution should maximize `run:` and `format:` blocks. Use `rules:` for behavioral guardrails, not for critical steps.

### Complexity Tiers

| Steps | Reliability | Guidance |
| ------- | ------------- | ---------- |
| < 20 | High | Agent follows precisely with minimal drift |
| 20–30 | Reliable | Add `run:`/`format:` blocks and user checkpoints at group boundaries |
| 30–50 | Moderate | Delegate sub-processes to other skills or subagents |
| > 50 | Low | Must decompose — agent will drift without intervention |

### Process Complexity Score (PCS)

An aggregated metric that combines individual complexity dimensions into a single score. Each dimension is normalized to its threshold and weighted by its impact on agent drift.

#### Formula

```text
PCS = 0.30×clamp₀₂(S/30) + 0.25×clamp₀₂(D/3) + 0.20×clamp₀₂(L/5) + 0.10×clamp₀₂(C/5) + 0.10×clamp₀₂(G/8) + 0.05×clamp₀₂(B/6) − 0.05×R
```

Where `clamp₀₂(x) = min(max(x, 0), 2)`.

| Weight | Symbol | Dimension | Threshold |
| -------- | -------- | ----------- | ----------- |
| 0.30 | **S** | Atomic steps | 30 |
| 0.25 | **D** | Max nesting depth (excl. `group`) | 3 |
| 0.20 | **L** | Loop constructs (`while` + `repeat` + `for-each`) | 5 |
| 0.10 | **C** | Conditionals — count of `if` keywords; each nested `if` counts separately; `elsif`/`else` do not increment C | 5 |
| 0.10 | **G** | Group blocks | 8 |
| 0.05 | **B** | Parallel branches — total `branch` blocks across all `parallel:` blocks in the process | 6 |
| −0.05 | **R** | Run density — `steps_with_run / S`; atomic steps with a `run:` keyword ÷ total atomic steps | ratio [0, 1] |

Positive weights sum to **1.00**. R discount is applied after.

**Clamping:** Each ratio is clamped to `[0, 2]` before weighting. A 60-step process scores 2× on the S dimension, not unbounded.

**Run density discount:** R is subtracted because `run:` blocks have the highest agent fidelity (see Elaboration Keyword Fidelity above). More `run:` blocks = lower effective complexity.

**Calibration:** A process at all seven dimension limits (S=30, D=3, L=5, C=5, G=8, B=6, R=0) scores **1.0**. A process at just the X1–X4 limits (S=30, D=3, L=5, G=8) scores **0.85** (High).

#### Tiers

| PCS Range | Label | Meaning |
| ----------- | ------- | --------- |
| 0.00–0.40 | **Low** | Agent follows precisely; no intervention needed |
| 0.41–0.70 | **Moderate** | Reliable with checkpoints; add `run:`/`format:` blocks |
| 0.71–1.00 | **High** | Decompose into sub-skills or add verification loops |
| > 1.00 | **Critical** | Must decompose — agent will drift without intervention |

#### Example Scores

| Process | S | D | L | C | G | B | R | PCS | Tier |
| --------- | --- | --- | --- | --- | --- | --- | --- | ----- | ------ |
| CIWorkflow (§9) | 5 | 1 | 0 | 0 | 0 | 3 | 0.0 | 0.16 | Low |
| Brainstorming (§9) | 2 | 1 | 1 | 0 | 0 | 0 | 0.0 | 0.14 | Low |
| PlanReview (§9) | 4 | 2 | 1 | 1 | 0 | 0 | 0.0 | 0.27 | Low |
| At X1–X4 limits | 30 | 3 | 5 | 0 | 8 | 0 | 0.0 | 0.85 | High |
| At all 7 limits | 30 | 3 | 5 | 5 | 8 | 6 | 0.0 | 1.00 | Critical |
| Large with run: blocks | 35 | 3 | 4 | 3 | 6 | 4 | 0.6 | 0.90 | High |

#### Contextual Suggestions

When X7 or X8 fires, append the first matching suggestion:

| Condition | Suggestion |
| ----------- | ------------ |
| S > 30, D ≤ 2 | Process is long but flat — delegate groups to sub-skills |
| D > 3, S ≤ 20 | Short but deeply nested — flatten by extracting inner blocks |
| C > 5 | Many conditionals — extract complex decision trees into sub-skills or simplify branching |
| L > 5 | Many loops — prefer `for-each` over `while`, add `max-iterations` |
| R < 0.3 | Low run density — add `run:` blocks to critical steps for higher agent fidelity |
| B > 6 | Many parallel branches — consider sequencing low-priority branches |
| PCS > 1.0, G > 4 | Split into multiple processes — each group could become its own skill |

### Strategies for Maintaining Precision

1. **User interaction checkpoints** — End groups with a user gate (`Ask`, `AskUserQuestion`). The user keeps the agent on track.
2. **Delegation** — Use `Invoke` to delegate self-contained groups to sub-skills rather than inlining everything. Delegation improves precision through three mechanisms:
   - **Fresh context** — Each sub-skill runs in a new agent turn with only its own process loaded. The subagent's full attention is on fewer steps, eliminating mid-process drift.
   - **Reduced parent complexity** — Replacing an inlined 15-step group with a single `Invoke` step lowers the parent's step count (S) and PCS, keeping it in a higher-reliability tier.
   - **State isolation** — The subagent does not carry the parent's accumulated `result:` values, preventing accidental conflation of earlier state with current work.

   Delegation has two forms:
   - **Full skill** (`Invoke skill '<name>'`) — Best for reusable sub-processes shared across multiple parents. Requires `skills/<name>/SKILL.md` with frontmatter.

     ```flowzy
     - Invoke skill 'flowcode:deploy-setup' to configure infrastructure
     ```

   - **Sub-process file** (via `flowzy-process-executor` subagent) — Best for one-off decompositions. The sub-process lives as a plain markdown file with a `flowzy` code block. No skill registration needed.

     ```flowzy
     - Launch flowzy-process-executor to run database migration
       run: |
         Task: subagent_type=flowzy-process-executor
           "Execute docs/sub-processes/db-migration.md"
     ```

3. **Verification loops** — `repeat/until` with a verifier subagent catches drift after autonomous sections.
4. **Binary exit conditions** — Prefer `until {verifier reports PASS}` over `until {idea is sufficiently understood}`. The more opaque the condition, the less predictable the loop behavior.
5. **`run:` over prose** — When a step must invoke a specific tool, always use `run:` rather than describing the invocation in the step text.

---

## 13. Quick Reference for AI Agents

@flowzy-quick-reference.md
