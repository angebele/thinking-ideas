---
name: discover
description: >-
  Use when defining a new product or feature from scratch and you need to identify
  user personas, user stories, and priorities BEFORE technical design. Produces a
  PRD with structured user stories and MoSCoW prioritization. Run this before
  /study when you need product-level clarity.
  Keywords: product discovery, PRD, user stories, personas, features, prioritization.
---

# Product Discovery to PRD

## CRITICAL CONSTRAINTS

**You MUST NOT call `EnterPlanMode` or `ExitPlanMode` at any point during this skill.** Calling `EnterPlanMode` traps the session in plan mode where Write/Edit are restricted. Calling `ExitPlanMode` breaks the pipeline's workflow.

**You MUST NOT implement any code changes during this skill without prior explicit approval from the user.**

## Overview

Transform a product idea into a PRD (Product Requirements Document) through collaborative dialogue, then guide the user to run `/study` on individual stories.

**Pipeline context:**

```
[Discover] ───> [Study] ───> [Implement]
 This skill      Design       Directly
 ├─ Understand context
 ├─ Research market (conditional)
 ├─ Review requirements
 ├─ Discover features
 ├─ Present & validate PRD
 ├─ Name feature & create dir
 ├─ Write PRD (markdown + HTML)
 └─ Handoff to study
```

## Process

@../../docs/flowzy-quick-reference.md

```flowzy
process Discover:

  # Understand the product context by asking questions iteratively
  group UnderstandContext:

    - Output status update
      format: |
        **Let me start by understanding your product idea and exploring the current project context**

    - Launch Explore agents to check the current project state
      run: |
        Task: subagent_type=Explore (launch 1-3 in parallel)
          "Analyze project file structure, docs, recent changes, and identify patterns relevant to the current context"

    repeat:
      - Ask one question to refine the user's product idea
        rules:
          - Prefer multiple choice when possible; open-ended is fine too
          - One question per message; break complex topics into multiple questions
          - Focus on: problem and who feels it, business goals/constraints, target users and workflow, measurable success criteria
      if {project exploration is useful to better understand the product context}:
        - Launch Explore agents to examine areas of interest
          run: |
            Task: subagent_type=Explore (launch 1-3 in parallel)
              "Examine areas of interest to better understand the product context"
      end-if
      - Think whether you understand the product context sufficiently well to review requirements
        result: context-understood
    until { <context-understood> }, max-iterations=12

    - Store the refined product context as the requirements for the next steps
      result: requirements

    - Output status update
      format: |
        **Great! I now have a clear picture of your product context. Let me review the requirements from multiple perspectives before discovering features.**

  end-group

  # Research the market, competitors, and best practices (conditional)
  group ResearchMarket:

    - Ask the user which research dimensions to investigate (selecting none skips research)
      result: research-dimensions
      run: |
        AskUserQuestion (multiSelect):
          Q1: "Which internet research dimensions should I run? (Recommended for net-new or consumer-facing products in unfamiliar domains. Select none to skip — recommended for internal tooling, well-known domains, or refactors of existing products.)"
            - Competitor / similar products
            - Market signals & user pain points
            - Best practices & domain patterns

    if {research-dimensions is empty}:
      - Output status update
        format: |
          **Skipping external research. Moving on to requirements review.**
    else:
      - Output status update
        format: |
          **Launching research agents in parallel for the selected dimensions in <research-dimensions>**

      - Launch one general-purpose agent per selected dimension in <research-dimensions>, all in a single message so they run in parallel
        run: |
          Agent (launch all selected in a single message, subagent_type=general-purpose, each with WebSearch + WebFetch):
            - [if Competitors in <research-dimensions>] "Research competitor and similar products for the following requirements. Identify 3-7 relevant products, their key features, differentiators, and pricing/positioning. Cite sources (URLs). Note which competitor patterns are table-stakes vs. differentiated. Report under 300 words.\n\nRequirements:\n<requirements>"
            - [if Market signals in <research-dimensions>] "Research market signals and user pain points for the following requirements. Search forums (Reddit, HN, Stack Overflow), reviews, and surveys for evidence of the problem and how users currently work around it. Cite sources. Highlight pain points the requirements may have missed. Report under 300 words.\n\nRequirements:\n<requirements>"
            - [if Best practices in <research-dimensions>] "Research established best practices, UX patterns, terminology, and domain conventions relevant to the following requirements. Cite sources. Flag conventions the requirements appear to violate or ignore. Report under 300 words.\n\nRequirements:\n<requirements>"

      - Aggregate findings from all launched agents into a synthesis
        result: research-findings
        rules:
          - Group findings by dimension
          - Number each finding for easy reference
          - Note which findings suggest changes to <requirements> vs. which are informational only

      - Output the research synthesis from <research-findings>
        format: |
          **External Research Findings**

          ### Competitors
          1. <finding> — <source>

          ### Market Signals & Pain Points
          1. <finding> — <source>

          ### Best Practices & Domain Patterns
          1. <finding> — <source>

      - Ask the user which findings from <research-findings> to incorporate into <requirements>
        rules:
          - Present as a multi-select referencing the numbered findings
          - Drive the interaction using natural collaborative dialogue
          - For each selected finding, update <requirements> accordingly

      - Output status update
        format: |
          **Requirements updated with selected research findings. Moving on to requirements review.**
    end-if

  end-group

  # Review requirements from 3 critical perspectives in parallel
  group ReviewRequirements:

    - Output status update
      format: |
        **Launching 3 requirements review agents in parallel**

    - Launch all 3 requirements review agents in parallel
      run: |
        Agent (launch all 3 in a single message):
          - subagent_type=req-review-contrarian
            "Review these product requirements with a contrarian perspective. Which user persona is fictional or overly broad? Which Must Have is actually a Should Have? What market assumption will prove wrong? Assume the idea has a fatal flaw and find it.\n\nRequirements:\n<requirements>"
          - subagent_type=req-review-first-principles
            "Review these product requirements from first principles. Is this solving the real user problem or a symptom? Strip away assumptions about what users want and rebuild from observed behavior and pain points.\n\nRequirements:\n<requirements>"
          - subagent_type=req-review-expansionist
            "Review these product requirements for missed upside. Which adjacent user segment would benefit from a slight scope adjustment? What leverage point in the user workflow hasn't been noticed?\n\nRequirements:\n<requirements>"

    - Aggregate findings from all 3 agents and categorize each finding
      rules:
        - **Critical** (confidence 90-100): User review required
        - **Important** (confidence 80-89): User review recommended
        - **Suggestion** (below 80): Informational only

    - Output aggregated review summary
      format: |
        **Product Requirements Review Summary**

        **Agents:** Contrarian, First Principles, Expansionist
        **Findings:** N Critical, N Important, N Suggestions

        ### Critical Issues
        - [agent] Finding description (confidence: N)

        ### Important Issues
        - [agent] Finding description (confidence: N)

        ### Suggestions
        - [agent] Finding description (confidence: N)

    if {any Critical or Important findings exist}:
      - Ask the user to review and decide which findings to incorporate
        rules:
          - Present findings conversationally, not as a wall of text
          - For Critical findings, ask explicitly whether to address each
          - For Important findings, recommend addressing but let the user decide
      - Update <requirements> based on user decisions
    else:
      - Output status update
        format: |
          **All three reviewers found the requirements robust. Moving on to discover features.**
    end-if

  end-group

  # Discover personas and user stories iteratively
  group DiscoverFeatures:

    - Output status update
      format: |
        **I'll now discover user personas and stories for the product**

    # Adaptive persona discovery
    - Ask how many distinct user types interact with the product
      rules:
        - Offer multiple choice: one, 2-3, more than 3

    if {single persona}:
      - Define the single persona briefly (~2-3 sentences)
        result: personas
    else:
      - Define each persona with: name/role, primary goal, key pain point
        result: personas
        rules:
          - Keep each persona definition concise
          - Validate personas with the user before proceeding to stories
    end-if

    # Iterative story discovery
    repeat:
      - Propose a batch of 2-4 related user stories for a workflow area or persona
        rules:
          - Default format is Connextra: "As a [persona], I want [capability], so that [outcome]"
          - Plain language acceptable when it communicates more clearly
          - Each story includes testable acceptance criteria
          - Assign tentative MoSCoW priority with brief rationale
          - Apply INVEST criteria: Independent, Negotiable, Valuable, Estimable, Small, Testable
      - Ask the user to validate, adjust, or expand the batch
        rules:
          - Be ready to split, merge, or add stories as needed
      - Think whether all workflow areas and personas have been covered
        result: stories-complete
    until { <stories-complete> }, max-iterations=10

    - Store all discovered stories

    # Priority confirmation pass
    - Output the full story list grouped by MoSCoW tier
      format: |
        **Priority Confirmation**

        ### Must Have
        - Story title — brief rationale

        ### Should Have
        - Story title — brief rationale

        ### Could Have
        - Story title — brief rationale

        ### Won't Have This Version
        - Story title — brief rationale

    - Ask the user to confirm or adjust priorities in a single pass
      rules:
        - Single confirmation pass, not per-story negotiation
        - User can move stories between tiers, combine, or remove

    - Store the finalized prioritized stories
      result: prioritized-stories

    - Output status update
      format: |
        **Personas and stories are finalized. I'll now present the full PRD for validation.**

  end-group

  # Present the PRD and clarify iteratively
  group PresentPRD:

    - Output status update
      format: |
        **Let me now present the Product Requirements Document**

    - Reference example PRDs for shape and tone (illustrative, not prescriptive)
      rules:
        - See @reference/example-prd-fr.md (French) or @reference/example-prd-en.md (English) for a compact, real-world PRD covering all 9 sections
        - Use them to calibrate section length, story format, and Won't/Open Questions style
        - Do NOT copy structure verbatim — adapt to the current product

    - Assemble the PRD from <requirements>, <personas>, and <prioritized-stories>, split into sections
      rules:
        - Section 1: Problem Statement (~100 words)
        - Section 2: Target Users / Personas (~100 words for single persona, expanded for multi)
        - Section 3: Goals & Success Metrics (bulleted, measurable)
        - Sections 4-7: User Stories by MoSCoW tier (each with acceptance criteria; Won't Have needs none)
        - Section 8: Out of Scope
        - Section 9: Open Questions (for study/design phase)
        - Omit empty priority tiers; combine Sections 4-7 if fewer than 6 stories total
        - Aim for 200-300 words per section; let content dictate length

    repeat:
      - Present each PRD section
      - Ask if the section looks right so far
      if {user requests changes}:
        - Revise section based on feedback
      end-if
    until {PRD is complete and all sections validated}, max-iterations=12

    - Output status update
      format: |
        **The PRD is complete and validated. I'll now write the document.**

  end-group

  # Name the feature and create the plans directory
  group NameFeature:

    - Classify the change type from <requirements>
      result: change-type
      rules:
        - Map to one prefix: feat, fix, refactor, docs, test, chore, hotfix
        - New capability or enhancement = feat
        - Broken behavior = fix
        - Structural change, no behavior change = refactor
        - Documentation only = docs
        - Test additions or fixes = test
        - Tooling, deps, config = chore
        - Urgent production issue = hotfix

    - Extract a short description from <requirements>
      result: short-description
      rules:
        - Lowercase, hyphens for spaces, 2-3 words (max 5)
        - Describe the what, not the how
        - Drop filler words (the, a, an, for, to)

    if {project is a monorepo}:
      - Determine the project scope
        result: project-scope
        rules:
          - Use the project or package name, lowercase
      - Assemble scoped branch name
        result: branch-feature-name
        format: |
          <change-type>/<project-scope>/<short-description>
    else:
      - Set the project scope to the repo name
        result: project-scope
        rules:
          - Use the repo name, lowercase
      - Assemble branch name
        result: branch-feature-name
        format: |
          <change-type>/<short-description>
    end-if

    - Derive document name prefix from <branch-feature-name>
      result: doc-feature-name
      rules:
        - Replace '/' with '-' in <branch-feature-name>

    - Identify the current date
      result: current-date
      run: |
        Bash: date +%Y-%m-%d

    - Define per-feature directory and PRD document names (markdown + HTML)
      result: feature-dir, prd-doc-name, prd-html-name
      rules:
        - <feature-dir> = `output/<current-date>-<doc-feature-name>`
        - <prd-doc-name> = `<doc-feature-name>-prd.md`
        - <prd-html-name> = `<doc-feature-name>-prd.html`

    - Create the feature directory
      run: |
        Bash: mkdir -p <feature-dir>
  end-group

  # Write the PRD document (markdown + single-page HTML) to disk
  group WritePRD:

    - Output status update
      format: |
        **Writing PRD document _'<prd-doc-name>'_**
    - Save the validated PRD to `<feature-dir>/<prd-doc-name>`
      result: prd-doc-path

    - Generate a single-page HTML version of the PRD
      result: prd-html-path
      rules:
        - Read @reference/example-prd-en.html and reuse it as the template for a self-contained, single-file HTML document
        - The HTML reference is a language-agnostic FORMAT and STYLE template — it shows the chrome and the markdown→HTML mapping, not content. Use it regardless of the PRD's language; do not look for a per-language HTML variant (there is intentionally only one)
        - Keep the example's `<head>`/`<style>` and the trailing table-of-contents / scroll-spy `<script>` (the IIFE at the end of `<body>`) VERBATIM — they are generic and build the sidebar nav from whatever headings exist
        - The template intentionally contains NO third-party scripts. Add the mermaid library ONLY when the PRD actually contains mermaid diagrams; a PRD with no diagrams must stay fully local with zero external dependencies
        - Replace ONLY the body content: convert the validated PRD markdown to semantic HTML
          - Render each markdown heading as the matching `<h1>`-`<h6>` with a slugified `id` (lowercase; non-alphanumeric runs collapse to a single hyphen), so the auto-generated sidebar links resolve
          - Convert lists, tables, `<hr>`, inline code, bold/italic, and links faithfully
          - If (and only if) the PRD contains mermaid diagrams: render each as `<pre class="mermaid">...</pre>`, add this pinned, integrity-checked loader just before `</head>` — `<script src="https://unpkg.com/mermaid@11.15.0/dist/mermaid.min.js" integrity="sha384-yQ4mmBBT+vhTAwjFH0toJXNYJ6O4usWnt6EPIdWwrRvx2V/n5lXuDZQwQFeSFydF" crossorigin="anonymous"></script>` — and initialize it at the start of `<body>` with `<script>mermaid.initialize({ startOnLoad: true });</script>`. Never use an unpinned `@latest` URL and never omit the `integrity` hash
        - Set the `<title>` to `<prd-doc-name>`
        - Add no external dependencies other than the pinned, integrity-checked mermaid loader above (and only when diagrams are present); the file must open standalone in a browser
    - Save the HTML to `<feature-dir>/<prd-html-name>`
      rules:
        - Write files only — do NOT run any git command (no add, no commit). Do not assume the project is a git repository
    - Output status update
      format: |
        **PRD documents `<prd-doc-name>` (markdown) and `<prd-html-name>` (HTML) written to `<feature-dir>/`. Discovery phase complete.**
  end-group

  # Guide the user to run /study on the recommended first story
  group HandoffToStudy:

    - Identify the recommended first story from <prioritized-stories>
      result: recommended-story
      rules:
        - Pick the Must Have story that is most foundational or most valuable standalone
        - If tied, prefer the one with clearest acceptance criteria

    - Output handoff message
      format: |
        **Product Discovery complete. Ready for Study & Design.**

        ### Recommended Next Step

        Start with this story:
        > <recommended-story title and description>

        Run:
        ```
        /study <recommended-story — brief description of the story to study>
        ```

        ### Story Backlog

        | # | Story | Priority | Status |
        |---|-------|----------|--------|
        | 1 | <story title> | Must Have | **Start here** |
        | 2 | <story title> | Must Have | Pending |
        | ... | ... | ... | ... |

        Work through **Must Have** stories first, then **Should Have**.
        Each story gets its own `/study` -> implementation cycle.

    - Exit process
  end-group
```

## Key Principles

- **Natural collaborative dialogue** - Drive the conversation; lead the user through discovery, don't wait for them to direct each step. Applies to ALL interactive steps.
- **One question at a time** - Don't overwhelm with multiple questions
- **Multiple choice preferred** - Easier to answer than open-ended when possible
- **Propose your recommended option** - Always propose your recommended option or action, and justify your recommendation
- **Batch story proposals** - Present 2-4 related stories together, not one-by-one
- **Adaptive depth** - Brief for simple products, expanded for complex multi-persona products
- **Research before stress-testing** - When external research runs, it precedes requirements review so reviewers can critique informed assumptions, not blind ones
- **YAGNI ruthlessly** - Won't Have tier exists to explicitly park ideas
- **Incremental validation** - Present PRD in sections, validate each
- **Format flexibility** - Connextra as default, plain language when clearer
