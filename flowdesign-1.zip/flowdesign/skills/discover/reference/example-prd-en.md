# PRD — `monoi-choc` blog: food autonomy

- **Feature** : `feat/mc-blog-monoi-choc`
- **Date**: 2026-04-27
- **Status**: illustrative example (shortened from a real PRD)
- **Author**: ekain-fr

> This example is a format reference for the `discover` skill. It is not prescriptive: adapt length and detail to your own product.

---

## 1. Problem Statement

People aged 30-60 changing their diet — by constraint (intolerances) or by choice (plant transition) — don't lack information; they lack **confidence, sequencing, and permission**. They fear four things: nutritional deficiency, monotony, daily decision paralysis, and complex recipes. On top sits a rarely-addressed social friction: eating out, hosting, and traveling without anxiety. The market offers either recipe blogs or expensive premium programs. What's missing is a free editorial companion that builds autonomy and prepares a future paid offering.

## 2. Target Users / Personas

Two primary personas. Other profiles (mixed-diet household, host, parent, traveler) are covered through cross-cutting tags.

- **Persona A — Inès, the intolerant seeking autonomy.** 30-60, urban, recent diagnosis (gluten/eggs). Goal: varied, safe meals without giving up social life. Pain points: fear of cross-contamination, mental fatigue from improvised substitutions, recurring nutritional doubt, isolation.
- **Persona B — Paul, the plant-transitioner.** 30-60, no medical intolerance, motivated by health/environment. Goal: cut animal protein without deficiency or family conflict. Pain points: fear of missing nutrients (iron, B12), boredom, social pressure, mixed-diet household.

**Cross-cutting tags**: `mixed-household`, `hosting`, `kids`, `travel`.

## 3. Goals & Success Metrics

Build a qualified audience base in 3-4 months to launch paid guides in Phase 2.

| Metric | Target | Rationale |
|--------|--------|-----------|
| Newsletter subscribers | 200 | Minimum volume to test a paid guide in P2 |
| Quiz → signup conversion | ≥ 25 % | Quiz quality, independent of traffic |
| Newsletter open rate | ≥ 40 % | Standard for engaged audience |
| Quiz completion rate | ≥ 70 % | Below this: too long or too abstract |

**Out of scope for Phase 1 KPIs**: direct revenue, large organic SEO traffic, purchase conversion.

## 4. User stories — MUST HAVE

#### US1.1 — Personalized diagnostic quiz

> As a visitor, I want to take a short quiz (6-8 questions) and receive a PDF tailored to my profile, so that I get advice aligned with my situation rather than a generic resource.

- 6-8 conditional-branching questions (intolerance vs transition, stage, household)
- Result = 1 PDF among ≥ 3 variants at launch
- Automatic Brevo tagging (`profile:*`, `stage:*`)
- Completion < 90 s; rate ≥ 70 %

#### US4.1 — Passwordless authentication (magic link / passkey / OAuth)

> As a visitor wanting to create an account, I want to sign up and log in without a password, so that I can access my space without friction.

- `/auth` page with 3 entry points: magic link, passkey, OAuth (Google/Apple/Meta)
- Magic link: signed token, 15-min expiry, single use
- HTTP-only session cookie, 30-day duration, 3/hour rate limit per email
- Stack: `better-auth` + `better-sqlite3` (driver TBD in study)

#### US5.1 — Weekly newsletter with a clear promise

> As a subscriber, I want one short email per week with a "This week let's try…" promise, so that I get an actionable dose without feeling overwhelmed.

- Fixed cadence (Sunday morning by default)
- ≤ 300 words: 1 challenge + 2-3 curated links
- Brevo segmentation variants (intolerant vs plant-based)
- GDPR unsubscribe link in every email

## 5. User stories — SHOULD HAVE

#### US5.3 — Printable shopping list

> As a user planning groceries, I want to aggregate ingredients from multiple recipes into one list, so that I save time at the store and reduce missed items.

- Multi-select from listings or favorites
- Aggregation by ingredient + unit when consistent
- Grouping by aisle (produce / pantry / fresh)
- Printable PDF export + tickable online version

## 6. User stories — COULD HAVE

#### US4.4 — GDPR account export & deletion

> As a user, I want to export my data and delete my account self-service, so that I exercise my GDPR rights without going through support.

- JSON export (account, favorites, quiz profile, dates)
- Deletion: email confirmation + 7-day grace period + full purge
- Until self-service ships: documented `support@…` channel

## 7. Won't Have (this version)

| Story | Horizon | Reason |
|-------|---------|--------|
| Active waitlist per paid guide | P2 | No active teasing in P1 |
| Any payment processing | P1.5+ | No purchase flow in P1 |
| Online courses / 1:1 coaching | P1.5/P2 | Course platform and calendar out of scope |
| Multi-language | P1.5/P2 | French only in P1 |

## 8. Out of Scope

- Comments, ratings, forum
- Native mobile app (PWA possible later)
- Per-recipe nutritional calculations (legal/health-claims risk)
- Visual CMS (Sanity, Strapi)
- Third-party meal-planning sync (Yummly, Mealime)

## 9. Open Questions

**Product & content**
1. How many lead-magnet PDF variants at launch (3 or 4-5)?
2. Editorial tone: informal "tu" or formal "vous"?

**Auth & data**
3. SQLite driver with better-auth: Drizzle or Prisma?
4. Hetzner VPS backup and disaster recovery — frequency, off-site?

**Acquisition**
5. Instagram cadence plan to support landing pages — to be formalized outside dev.

---

## Next steps

Next phase: `/study` on MUST HAVE stories. **Recommended starting story**: US4.1 (passwordless auth) — technical foundation that favorites, account space, and Brevo continuity all depend on, and the riskiest workstream (better-auth is young).
