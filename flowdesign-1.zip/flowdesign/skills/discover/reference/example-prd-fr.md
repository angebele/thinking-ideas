# PRD — Blog `monoi-choc` : autonomie alimentaire

- **Feature** : `feat/mc-blog-monoi-choc`
- **Date** : 2026-04-27
- **Statut** : exemple illustratif (PRD réel raccourci)
- **Auteur** : ekain-fr

> Cet exemple sert de référence de format pour la skill `discover`. Il n'est pas prescriptif : adaptez la longueur et le détail à votre produit.

---

## 1. Problem Statement

Les personnes de 30-60 ans qui changent d'alimentation — par contrainte (intolérances) ou par choix (transition végétale) — ne manquent pas d'information mais de **confiance, séquence et permission**. Elles redoutent quatre choses : carences nutritionnelles, monotonie, paralysie du quotidien, complexité des recettes. S'y ajoute un frein social rarement adressé : sortir, recevoir, voyager sans angoisse. Le marché propose soit des blogs de recettes, soit des programmes premium coûteux. Il manque un compagnon éditorial gratuit qui rend autonome et prépare un passage payant futur.

## 2. Cibles & personas

Deux personas primaires. Les autres profils (foyer multi-régimes, hôte, parent, voyage) sont couverts par des tags transverses.

- **Persona A — Inès, l'intolérante en quête d'autonomie.** 30-60 ans, urbaine, diagnostic récent (gluten/œufs). Objectif : alimentation variée et sûre sans renoncer à sa vie sociale. Pain points : peur de la contamination, fatigue mentale des substitutions, doute nutritionnel, isolement.
- **Persona B — Paul, le transitionnaire végétal.** 30-60 ans, sans intolérance médicale, motivé santé/environnement. Objectif : réduire les protéines animales sans carences ni conflit familial. Pain points : peur du manque (fer, B12), lassitude, pression sociale, repas familial mixte.

**Tags transverses** : `famille-mixte`, `recevoir`, `enfants`, `voyage`.

## 3. Objectifs & métriques de succès

Construire en 3-4 mois la base d'audience qualifiée pour lancer en Phase 2 des dossiers payants.

| Métrique | Cible | Justification |
|----------|-------|---------------|
| Inscrits newsletter | 200 | Volume minimal pour tester un dossier payant en P2 |
| Conversion quiz → inscription | ≥ 25 % | Qualité du quiz, indépendant du trafic |
| Taux d'ouverture newsletter | ≥ 40 % | Standard audience engagée |
| Complétion du quiz | ≥ 70 % | Sous ce seuil : trop long ou trop abstrait |

**Hors KPI Phase 1** : revenus directs, SEO organique massif, conversion en achat.

## 4. User stories — MUST HAVE

#### US1.1 — Quiz diagnostic personnalisé

> En tant que visiteur, je veux passer un quiz court (6-8 questions) pour recevoir un PDF adapté à mon profil, afin d'obtenir des conseils alignés avec ma situation plutôt qu'une ressource générique.

- 6-8 questions à branchements conditionnels (intolérance vs transition, stade, foyer)
- Résultat = 1 PDF parmi ≥ 3 variantes au lancement
- Tagging Brevo automatique (`profile:*`, `stage:*`)
- Complétion < 90 s ; taux ≥ 70 %

#### US4.1 — Authentification passwordless (magic link / passkey / OAuth)

> En tant que visiteur souhaitant créer un compte, je veux m'inscrire et me connecter sans mot de passe, afin d'accéder à mon espace sans friction.

- Page `/auth` avec 3 voies : magic link, passkey, OAuth (Google/Apple/Meta)
- Magic link signé, expire 15 min, usage unique
- Cookie session HTTP-only, durée 30 jours, rate limit 3/h par email
- Stack : `better-auth` + `better-sqlite3` (driver à arrêter en study)

#### US5.1 — Newsletter hebdomadaire à promesse claire

> En tant qu'abonné, je veux recevoir 1 email/semaine court avec une promesse "Cette semaine on essaie…", afin d'avoir une dose actionnable sans me sentir submergé.

- Cadence fixe (dimanche matin par défaut)
- Format ≤ 300 mots : 1 défi + 2-3 liens curatés
- Variantes par segmentation Brevo (intolérant vs végétal)
- Lien désinscription RGPD dans chaque email

## 5. User stories — SHOULD HAVE

#### US5.3 — Liste de courses imprimable

> En tant qu'utilisateur planifiant ses courses, je veux agréger les ingrédients de plusieurs recettes en une liste, afin de gagner du temps et de limiter les oublis.

- Sélection multiple depuis listing ou favoris
- Agrégation par ingrédient + unité quand cohérent
- Regroupement par rayon (légumes / épicerie / frais)
- Export PDF imprimable + version "à cocher" en ligne

## 6. User stories — COULD HAVE

#### US4.4 — Export & suppression compte RGPD

> En tant qu'utilisateur, je veux exporter mes données et supprimer mon compte en self-service, afin d'exercer mes droits RGPD sans dépendre du support.

- Export JSON (compte, favoris, profil quiz, dates)
- Suppression : confirmation email + délai 7 jours + purge complète
- Tant que self-service absent : canal `support@…` documenté

## 7. Won't Have (cette version)

| Story | Horizon | Raison |
|-------|---------|--------|
| Waitlist active par guide payant | P2 | Pas de teasing actif en P1 |
| Tout traitement de paiement | P1.5+ | Aucun flux d'achat en P1 |
| Cours en ligne / coaching 1:1 | P1.5/P2 | Plateforme et calendrier hors périmètre |
| Multi-langue | P1.5/P2 | FR uniquement en P1 |

## 8. Out of Scope

- Commentaires, notes, forum
- Application mobile native (PWA possible plus tard)
- Calculs nutritionnels par recette (risque légal)
- CMS visuel (Sanity, Strapi)
- Sync apps tierces (Yummly, Mealime)

## 9. Open Questions

**Produit & contenu**
1. Nombre de variantes PDF lead magnet au lancement (3 ou 4-5) ?
2. Tonalité éditoriale : tutoiement ou vouvoiement ?

**Auth & données**
3. Driver SQLite avec better-auth : Drizzle ou Prisma ?
4. Backup et disaster recovery du VPS Hetzner — fréquence, off-site ?

**Acquisition**
5. Plan de cadence Instagram pour soutenir les LP — à formaliser hors dev.

---

## Prochaines étapes

Phase suivante : `/study` sur les stories MUST HAVE. **Story recommandée pour démarrer** : US4.1 (auth passwordless) — fondation technique dont dépendent favoris, espace compte et continuité Brevo, et workstream le plus risqué (better-auth jeune).
