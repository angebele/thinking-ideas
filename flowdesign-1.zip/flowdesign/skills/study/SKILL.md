---
name: study
description: Use when creating or developing anything, BEFORE writing any code -- creating features, building components, adding functionality, or modifying behavior. Explores user intent, requirements and design before implementation.
---

# Study Idea/Request Into Design

## CRITICAL CONSTRAINTS

**You MUST NOT call `EnterPlanMode` or `ExitPlanMode` at any point during this skill.** This skill operates in normal mode and manages its own completion flow. Calling `EnterPlanMode` traps the session in plan mode where Write/Edit are restricted. Calling `ExitPlanMode` breaks the pipeline's workflow. If you are about to call either, STOP — follow this skill's instructions instead.

**You MUST NOT implement any code changes during this skill without prior explicit approval from the user.** If you are about to implement any code changes, STOP — follow this skill's instructions instead. You MUST ask the user to approve direct implementation if you believe the change is trivial enough to not require the full process, but you MUST NOT implement without approval. The skill's instructions contains specific steps where the user can approve direct implementation; you MUST follow those instructions.

## Overview

Transform initial idea or request into fully formed design through natural collaborative dialogue, then implement it directly.

Start by understanding the current project context, then ask questions one at a time to refine the idea.
Once you understand what you're building, explore solutions and present the design in manageable sections (aiming for 200-300 words, adjusted to natural boundaries), checking after each section whether it looks right so far.
After the design doc is written and approved, implement the feature directly.

**Pipeline context:**

```
[Study & Design] ───────────────> [Implement directly]
 ^^^^^^^^^^^^^^
 This skill
 ├─ Understand request
 ├─ Review requirements (3 agents)
 ├─ Explore solutions
 ├─ Present & validate design
 ├─ Name feature & create dir
 ├─ Write design doc
 └─ Implement directly (after user confirms)
```

## Process

@../../docs/flowzy-quick-reference.md

```flowzy
process Study:

  # Understand the user's idea / request by asking questions iteratively
  group UnderstandRequest:

    - Output status update
      format: |
        **Let me start by understanding your request and exploring the current project context**

    - Launch Explore agents to check the current project state (overall file structure, docs, recent changes)
      run: |
        Task: subagent_type=Explore (launch 1-3 in parallel)
          "Analyze project file structure, docs, recent changes, and identify patterns relevant to the current context"

    # Ask questions one at a time to refine the user's idea / request
    repeat:
      - Ask one question to refine the user's idea / request
        rules:
          - Prefer multiple choice questions when possible, but open-ended is fine too
          - Only one question per message; if a topic needs more exploration, break it into multiple questions
          - Focus on understanding: purpose, constraints, success criteria
          - Drive the interactions using natural collaborative dialogue
      if {project exploration is useful to better understand the user's idea / request}:
        - Launch Explore agents to examine areas of interest
          run: |
            Task: subagent_type=Explore (launch 1-3 in parallel)
              "Examine areas of interest to better understand the user's idea / request"
      end-if
      - Think whether you understand the user's idea / request sufficiently well to move to the next step and explore solutions
        result: request-understood
    until { <request-understood> }, max-iterations=12

    - Store the refined idea / request as the requirements for the next steps
      result: requirements

    - Output status update
      format: |
        **Great! I now understand your request sufficiently well. Let me now review the requirements from multiple critical perspectives before exploring solutions.**

  end-group

  # Review requirements from 3 critical perspectives in parallel
  group ReviewRequirements:

    - Output status update
      format: |
        **Launching 3 requirements review agents in parallel to stress-test the requirements**

    - Launch all 3 requirements review agents in a single message so they run in parallel
      run: |
        Agent (launch all 3 in a single message):
          - subagent_type=req-review-contrarian
            "Review these requirements with a contrarian perspective. Look for what will fail. Assume the idea has a fatal flaw and find it.\n\nRequirements:\n<requirements>"
          - subagent_type=req-review-first-principles
            "Review these requirements from first principles. Ignore the proposed solution and ask what we're actually trying to solve. Strip away assumptions.\n\nRequirements:\n<requirements>"
          - subagent_type=req-review-expansionist
            "Review these requirements for missed upside. Hunt for adjacent opportunities and leverage points we haven't noticed.\n\nRequirements:\n<requirements>"

    - Aggregate findings from all 3 agents and categorize each finding
      rules:
        - **Critical** (confidence 90-100): User review required — present these first and ask user to address them
        - **Important** (confidence 80-89): User review recommended — present after critical items
        - **Suggestion** (below 80 but reported): Informational only — mention briefly

    - Output aggregated review summary
      format: |
        **Requirements Review Summary**

        **Agents:** Contrarian, First Principles, Expansionist
        **Findings:** N Critical, N Important, N Suggestions

        ### Critical Issues (user review required)
        - [agent] Finding description (confidence: N)

        ### Important Issues (user review recommended)
        - [agent] Finding description (confidence: N)

        ### Suggestions (informational)
        - [agent] Finding description (confidence: N)

    if {any Critical or Important findings exist}:
      - Ask the user to review and decide which findings to incorporate into the requirements
        rules:
          - Present findings conversationally, not as a wall of text
          - For each Critical finding, ask explicitly whether to address it
          - For Important findings, recommend addressing them but let the user decide
          - Drive the interactions using natural collaborative dialogue
      - Update <requirements> based on user decisions
    else:
      - Output status update
        format: |
          **All three reviewers found the requirements robust. Moving on to explore solutions.**
    end-if

  end-group

  # Explore different solutions
  group ExploreSolutions:

    - Output status update
      format: |
        **I'll now explore solutions**

    repeat:
      if {project exploration is useful to identify or validate solutions}:
        - Launch Explore agents to examine areas of interest
          run: |
            Task: subagent_type=Explore (launch 1-3 in parallel)
              "Examine areas of interest to identify or validate solutions"
      end-if
      - Identify potential solutions
        rules:
          - If one solution is clearly best, present it with rationale for why alternatives were ruled out
          - If 2-3 viable solutions exist, compare them across key trade-offs (complexity, maintainability, performance, etc.)
          - Follow SOLID and DRY principles
          - Apply YAGNI
      - Propose your recommendation with reasoning
        rules:
          - Lead with your recommended option and explain why
          - If multiple viable solutions, present trade-offs conversationally
          - Ask the user's preference
          - Drive the interactions using natural collaborative dialogue
      - Think whether you understand precisely the solution you have to build in order to satisfy <requirements>
        result: solution-understood
    until { <solution-understood> }, max-iterations=6

    - Output status update
      format: |
        **Good job! I understand precisely the solution I have to build to satisfy your requirements**

  end-group

  # Present the design and clarify iteratively
  group PresentDesign:

    - Output status update
      format: |
        **Let me now present the solution design**

    - Design the solution and split the design into sections, aiming for 200-300 words per section but adjusting to natural section boundaries — shorter for simple topics, longer for complex ones that shouldn't be split
      rules:
        - Cover: architecture, components, data flow, edge cases, performance, error handling, testing strategy
        - The testing section should establish the testing strategy (what types of tests, key scenarios to cover, test runner/framework) — not full test implementations. The Build phase will create the detailed testing plan that will elaborate on this foundation.
    repeat:
      - Present each design section
      - Ask if the section looks right so far
      if {user requests changes}:
        - Revise design based on feedback
          rules:
            - Be ready to go back and clarify if something doesn't make sense
            - Drive the interactions using natural collaborative dialogue
      end-if
    until {design is complete and all sections have been validated}, max-iterations=10

    - Store the validated design document for the next steps
      result: validated-design

    - Output status update
      format: |
        **Excellent! The solution design is complete and validated. I'll now assess the implementation complexity.**

  end-group

  # Name the feature and create the plans directory
  group NameFeature:
    - Classify the change type from <validated-design> to determine the appropriate branch naming prefix
      result: change-type
      rules:
        - Map to one prefix: feat, fix, refactor, docs, test, chore, hotfix
        - New capability = feat
        - Broken behavior = fix
        - Enhancement to existing feature = feat
        - Structural change with no behavior change = refactor
        - Documentation only = docs
        - Test additions or fixes = test
        - Tooling, deps, config = chore
        - Urgent production issue = hotfix

    - Extract a short description from <validated-design>
      result: short-description
      rules:
        - Lowercase only
        - Replace spaces with hyphens
        - IMPORTANT: ideally use 2-3 words, maximum 4-5 words
        - Describe the what, not the how
        - Drop filler words (the, a, an, for, to)

    if {project is a monorepo}:
      - Determine the project scope
        result: project-scope
        rules:
          - Use the project or package name
          - Lowercase, no hyphens needed if single word
      - Assemble scoped branch name
        result: branch-feature-name
        format: |
          <change-type>/<project-scope>/<short-description>
    else:
      - Set the project scope to the repo name
        result: project-scope
        rules:
          - Use the repo name
          - Lowercase, no hyphens needed if single word
      - Assemble branch name
        result: branch-feature-name
        format: |
          <change-type>/<short-description>
    end-if

    - Derive document name prefix from <branch-feature-name>
      result: doc-feature-name
      rules:
        - Replace '/' with '-' in <branch-feature-name>
        - Result is the base name without date prefix (date added by caller)

    - Identify the current date
      result: current-date
      run: |
        Bash: date +%Y-%m-%d

    - Define per-feature directory and design document name
      result: feature-dir, design-doc-name
      rules:
        - <feature-dir> = `output/<current-date>-<doc-feature-name>`
        - <design-doc-name> = `<doc-feature-name>-design.md`

    - Create the feature directory
      run: |
        Bash: mkdir -p <feature-dir>
  end-group

  # Write the Design document to disk
  group WriteDesignDoc:
    - Output status update
      format: |
        **Writing Design document _'<design-doc-name>'_**
    - Save <validated-design> to `<feature-dir>/<design-doc-name>`
      result: design-doc-path
      rules:
        - Create directory `<feature-dir>/` if it doesn't exist
        - Write files only — do NOT run any git command (no add, no commit). Do not assume the project is a git repository
    - Output status update
      format: |
         **Design document `<design-doc-name>` written to `<design-doc-path>`. Design phase complete.**
  end-group

  # Design doc written above — confirm with the user, then implement directly
  group Implement:
    - Ask the user to confirm before starting implementation
      run: |
        AskUserQuestion:
          Q1: "The design document is written. Would you like me to implement it now?"
            - Option A: "Yes, implement it now"
            - Option B: "No, stop here — I'll take it from the design doc"
    if {user declines implementation}:
      - Output status update
        format: |
          **Stopping after design. The design document is ready whenever you want to implement it.**
      - Exit process
    else:
      - Output status update
        format: |
          **Design confirmed. Proceeding with direct implementation.**
      - Implement the proposed feature directly, following the design document
      - Prepare a detailed implementation plan and use todo tasks for tracking
      - Update any relevant documentation
      - Exit process
    end-if
  end-group
```

## Key Principles

- **Drive the conversation** - Use natural collaborative dialogue to lead the user through the process, don't wait for them to tell you what to do at each step
- **One question at a time** - Don't overwhelm with multiple questions
- **Multiple choice preferred** - Easier to answer than open-ended when possible
- **Propose your recommended option** - Always propose your recommended option or action, and justify your recommendation
- **YAGNI ruthlessly** - Remove unnecessary features from all designs
- **Explore alternatives** - Propose solutions before settling; present the best with reasoning
- **Incremental validation** - Present design in sections, validate each
- **Clarify edge cases** - Don't leave any ambiguity in the design
- **Be flexible** - Go back and clarify when something doesn't make sense
